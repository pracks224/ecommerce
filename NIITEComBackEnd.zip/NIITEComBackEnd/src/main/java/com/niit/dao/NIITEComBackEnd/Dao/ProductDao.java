package com.niit.dao.NIITEComBackEnd.Dao;

import java.util.List;

import com.niit.dao.NIITEComBackEnd.entity.Products;



public interface ProductDao{
	
	List<Products> getAllProducts();
	
	Products getProductById(int id);
	
	void updateProductById(Products product);

}
