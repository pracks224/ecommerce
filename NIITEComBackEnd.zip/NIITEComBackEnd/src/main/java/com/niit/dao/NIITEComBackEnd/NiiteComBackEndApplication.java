package com.niit.dao.NIITEComBackEnd;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


import com.niit.dao.NIITEComBackEnd.Dao.ArticleDAO;
import com.niit.dao.NIITEComBackEnd.Dao.ProductDaoImpl;

@SpringBootApplication
public class NiiteComBackEndApplication implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(NiiteComBackEndApplication.class, args);
	}
	
	  @Autowired
	    private ArticleDAO articleDAO;
	  
	  @Autowired
		ProductDaoImpl dao;
	    
	  


		@Override
		public void run(String... arg0) throws Exception {
			System.out.println("*******************"+articleDAO.getAllArticles().size());
			System.out.println("^^^^^^^^^^^^"+dao.getAllProducts().size());
			
		}
}
