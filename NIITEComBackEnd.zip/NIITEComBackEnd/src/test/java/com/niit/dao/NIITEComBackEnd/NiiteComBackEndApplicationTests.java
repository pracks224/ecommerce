package com.niit.dao.NIITEComBackEnd;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import com.niit.dao.NIITEComBackEnd.Dao.ArticleDAO;
import com.niit.dao.NIITEComBackEnd.Dao.IArticleDAO;

@RunWith(SpringRunner.class)
@DataJpaTest
@ComponentScan(basePackages = "com.niit.dao.NIITEComBackEnd.Dao")
public class NiiteComBackEndApplicationTests {
	@Autowired
	private IArticleDAO articleDAO;

	@Test
	public void testFindByName() {
		System.out.println("*******************" + this.articleDAO.getArticleById(1).getTitle());

	}
}
